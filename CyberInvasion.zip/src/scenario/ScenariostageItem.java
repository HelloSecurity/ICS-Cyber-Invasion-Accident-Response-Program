package scenario;

public class ScenariostageItem {
	private int id;	
	private int seq;
	private String scenario_timeline;
	private String scenario_phase;
	private String scenario_activity;
	private String group_RR;
	private String complete_condition;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getScenario_timeline() {
		return scenario_timeline;
	}
	public void setScenario_timeline(String scenario_timeline) {
		this.scenario_timeline = scenario_timeline;
	}
	public String getScenario_phase() {
		return scenario_phase;
	}
	public void setScenario_phase(String scenario_phase) {
		this.scenario_phase = scenario_phase;
	}
	public String getScenario_activity() {
		return scenario_activity;
	}
	public void setScenario_activity(String scenario_activity) {
		this.scenario_activity = scenario_activity;
	}
	public String getGroup_RR() {
		return group_RR;
	}
	public void setGroup_RR(String group_RR) {
		this.group_RR = group_RR;
	}
	public String getComplete_condition() {
		return complete_condition;
	}
	public void setComplete_condition(String complete_condition) {
		this.complete_condition = complete_condition;
	}
	
}

