package result;

public class Result {
	private int finalPriority;
	private String control_field;
	private String control_item_no;
	private String control_item;
	private String check_item;
	private String management;
	private String physics;
	private String method;
	private String result;
	private String action;
	
	public int getFinalPriority() {
		return finalPriority;
	}
	public void setFinalPriority(int finalPriority) {
		this.finalPriority = finalPriority;
	}
	public String getControl_field() {
		return control_field;
	}
	public void setControl_field(String control_field) {
		this.control_field = control_field;
	}
	public String getControl_item_no() {
		return control_item_no;
	}
	public void setControl_item_no(String control_item_no) {
		this.control_item_no = control_item_no;
	}
	public String getControl_item() {
		return control_item;
	}
	public void setControl_item(String control_item) {
		this.control_item = control_item;
	}
	public String getCheck_item() {
		return check_item;
	}
	public void setCheck_item(String check_item) {
		this.check_item = check_item;
	}
	public String getManagement() {
		return management;
	}
	public void setManagement(String management) {
		this.management = management;
	}
	public String getPhysics() {
		return physics;
	}
	public void setPhysics(String physics) {
		this.physics = physics;
	}
	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	
}
