package InfringmentAction;

public class InfringmentStageItem {
	private int seq;
	private int id;
	private String schedule;
	private String perform_sub;
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSchedule() {
		return schedule;
	}
	public void setSchedule(String schedule) {
		this.schedule = schedule;
	}
	public String getPerform_sub() {
		return perform_sub;
	}
	public void setPerform_sub(String perform_sub) {
		this.perform_sub = perform_sub;
	}
	
}
